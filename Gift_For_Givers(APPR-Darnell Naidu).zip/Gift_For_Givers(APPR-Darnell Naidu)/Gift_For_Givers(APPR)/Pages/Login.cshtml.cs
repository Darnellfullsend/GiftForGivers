using Gift_For_Givers_APPR_.Data;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace Gift_For_Givers_APPR_.Pages
{
    public class LoginModel : PageModel
    {
        //This lets the program user DBContext so that it can look at the database for users
        private readonly ApplicationDBContext dbContext;
        //Binds the user model to the page so that the Login data can be retrieved
        [BindProperty]
        public userData Login { get; set; }
        public LoginModel(ApplicationDBContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public void OnGet()
        {
        }
        //This will check if the user exists on the database upon POST and then allow the user to use the other page links if they exist
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                // Retrieve the user from the database based on the provided username
                var user = dbContext.USERS.FirstOrDefault(u => u.EMAIL == Login.EMAIL);

                // Check if the user exists and the password matches
                if (user != null && VerifyPassword(Login.PASSWORD, user.PASSWORD))
                {


                    // Set claims, including USER_ID
                    //This will create a claim our of the UserID and the Username
                    var claims = new List<Claim>
                    {
                        new Claim("USERID", user.USERID.ToString()),
                        new Claim("EMAIL", user.EMAIL),

                    };

                    var claimsIdentity = new ClaimsIdentity(claims, "login");
                    //This will let us Authenticate the user
                    var authProperties = new AuthenticationProperties();

                    HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                authProperties).Wait();

                    // TempData["Username"] = user.Username; 
                    // TempData["DebugUserIdClaim"] = $"UserId Claim: {user.USER_ID}";

                    // Redirects to the ModuleList page if user ID matches
                    var returnUrl = "/Volunteer?USERID=" + user.USERID;

                    // Redirect to the index page
                    return RedirectToPage("/Volunteer", new { USERID = user.USERID });


                }
                else
                {
                    // Invalid username or password
                    ModelState.AddModelError(string.Empty, "Invalid username or password");
                }
            }

            // If ModelState is not valid, return to the login page
            return Page();
        }
        //This hashes the entered password. Our login will then compared it to the hash with the database and it if matches the user will be able to log in
        static bool VerifyPassword(string enteredPassword, string storedPassword)
        {
            var sha = SHA256.Create();
            var enteredPasswordHash = Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(enteredPassword)));

            return enteredPasswordHash == storedPassword;
        }
    }

}
