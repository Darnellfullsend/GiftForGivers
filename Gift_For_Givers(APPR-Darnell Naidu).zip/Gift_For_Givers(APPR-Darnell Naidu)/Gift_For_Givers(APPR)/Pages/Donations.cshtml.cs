using Gift_For_Givers_APPR_.Data;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Security.Principal;

namespace Gift_For_Givers_APPR_.Pages
{
    public class DonationsModel : PageModel
    {
        //This pulls in our DBContext so that we can manipulate our database data
        private readonly ApplicationDBContext _dbContext;
        [BindProperty]
        public donate donations { get; set; }
        public DonationsModel(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            _dbContext.DONATIONS.Add(donations);
            _dbContext.Database.SetCommandTimeout(120);
            _dbContext.SaveChanges();

            return Page();
        }

    }
    public class donate
    {
        [Key]
        public int? DONATIONID { get; set; }
        [Required]
        public string? DONATION_NAME { get; set; }
        [Required]
        public string? DONATION_TYPE { get; set; }
        [Required]
        public string? DONATION_DETAILS { get; set; }
        [Required]
        public decimal? DONATION_MONEY { get; set; }
        // [Required]
        // public int? USERID { get; set; }

    }


}