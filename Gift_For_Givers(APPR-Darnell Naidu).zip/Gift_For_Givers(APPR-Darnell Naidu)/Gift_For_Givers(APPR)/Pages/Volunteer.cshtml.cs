using Gift_For_Givers_APPR_.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Gift_For_Givers_APPR_.Pages
{
    public class VolunteerModel : PageModel
    {
        //This pulls in our DBContext so that we can manipulate our database data
        private readonly ApplicationDBContext _dbContext;
        [BindProperty]
        public volunteer volunteers { get; set; }
        public tasks voltasks { get; set; }
        
        public VolunteerModel(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public IActionResult OnPost()
        {
            
            _dbContext.VOLUNTEER.Add(volunteers);
            _dbContext.Database.SetCommandTimeout(120);
            _dbContext.SaveChanges();

            return Page();
        }
    }
    
    
    public class volunteer
    {
        [Key]
        public int? VOLUNTEERID { get; set; }
        [Required]
        public string? VOLUNTEER_NAME { get; set; }
        [Required]
        public string? VOLUNTEER_EMAIL {  get; set; }
        [Required]
        public string? VOLUNTEER_NUMBER { get; set; }
        [Required]
        public string? VOLUNTEER_SKILLS { get; set; }
        [Required]
        public string? AVAILABILITY { get; set; }
        [Required]
        public string? ADDRESS { get; set; }
        //[ForeignKey]
        //public int? USERID { get; set; }
    }
    public class tasks
    {
        [Key]
        public int? TASKID { get; set; }
        [Required]
        public string? TASK_NAME { get; set; }
      
        [ForeignKey("volunteer")]
        [BindNever]
        public int? VOLUNTEERID { get; set; }
    }
}
