using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Gift_For_Givers_APPR_.Pages
{
    public class UserSettingsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
