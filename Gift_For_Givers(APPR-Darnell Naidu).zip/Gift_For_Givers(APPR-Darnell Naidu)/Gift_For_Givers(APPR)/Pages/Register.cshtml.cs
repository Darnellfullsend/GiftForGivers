using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Security.Cryptography;
using Gift_For_Givers_APPR_.Data;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Gift_For_Givers_APPR_.Pages
{
    public class RegisterModel : PageModel
    {
        private readonly ApplicationDBContext _dbContext;

        [BindProperty]
        public userData userReg { get; set; }

        public RegisterModel(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (ModelState.IsValid)
            {
                // Hash the password before saving to the database
                userReg.PASSWORD = Encrypt(userReg.PASSWORD);

                _dbContext.USERS.Add(userReg);
                _dbContext.Database.SetCommandTimeout(120);
                await _dbContext.SaveChangesAsync();

                return RedirectToPage("/RegistrationSuccessful");
            }

            return Page();
        }

        static string Encrypt(string value)
        {
            var sha = SHA256.Create();
            var encoding = Encoding.UTF8.GetBytes(value);
            var hashPass = sha.ComputeHash(encoding);
            return Convert.ToBase64String(hashPass);
        }
    }
    
    public class userData
    {
        [Key]
        public int? USERID { get; set; }

        [Required]
        public string? FIRST_NAME { get; set; }

        [Required]
        public string? LAST_NAME { get; set; }

        [Required]
        [EmailAddress]
        public string? EMAIL { get; set; }

        [Required]
        [Phone]
        public string? PHONE_NUMBER { get; set; }

        // This stores the plain password for confirmation before encryption
        [Required]
        [DataType(DataType.Password)]
        public string? PASSWORD { get; set; }

        // Confirm password with validation
        [NotMapped]
        [DataType(DataType.Password)]
        [Compare("PASSWORD", ErrorMessage = "Your passwords dont match.")]
        public string? CONFIRM_PASSWORD { get; set; }
    }
}
