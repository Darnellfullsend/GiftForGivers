using Gift_For_Givers_APPR_.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Gift_For_Givers_APPR_.Pages
{
    
    public class Disaster_ReportModel : PageModel
    {
        //This pulls in our DBContext so that we can manipulate our database data
        private readonly ApplicationDBContext _dbContext;
        [BindProperty]
        public DisasterReport Disaster { get; set; }
        public Disaster_ReportModel(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        
        public IActionResult OnPost()
        {
            _dbContext.DISASTER_REPORTS.Add(Disaster);
            _dbContext.Database.SetCommandTimeout(120);
            _dbContext.SaveChanges();
         
            return Page();
        }
        
    }
    public class DisasterReport
    {
        [Key]
        public int ?DISASTERID { get; set; }
        [Required]
        public string ?DISASTER_NAME { get; set; }
        
        [Required]
        public string? DISASTER_TYPE {  get; set; }
        [Required]
        public string? DISASTER_DETAILS { get; set; }
        [Required]
        public string? EMAILS { get; set; }
        //Foreign Key
        //[ForeignKey]
        // public int? USERID { get; set; }
    }
}
