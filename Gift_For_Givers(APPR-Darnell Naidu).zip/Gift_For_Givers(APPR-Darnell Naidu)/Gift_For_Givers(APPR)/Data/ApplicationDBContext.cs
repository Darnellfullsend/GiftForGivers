﻿using Gift_For_Givers_APPR_.Pages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace Gift_For_Givers_APPR_.Data
{
    public class ApplicationDBContext:DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options)
        {

        }
        public DbSet<DisasterReport> DISASTER_REPORTS { get; set; }
        public DbSet<volunteer> VOLUNTEER { get; set; }
        public DbSet<donate> DONATIONS { get; set; }
        public DbSet<userData> USERS { get; set; }

        public DbSet<tasks>TASK { get; set; }
    }
}
